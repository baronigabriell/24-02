package sp.senai.br.imc;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    EditText etAltura, etPeso;
    TextView tvResultado;
    Button btnCalcular, btnNovo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.clPrincipal), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        etPeso = findViewById(R.id.etPeso);
        etAltura = findViewById(R.id.etAltura);
        tvResultado = findViewById(R.id.tvResultado);
        btnCalcular = findViewById(R.id.btnCalcular);
        btnNovo = findViewById(R.id.btnNovo);
    }
    public void calcular (View c){
        float fPeso, fAltura, fResultado;

        fPeso = Float.parseFloat(etPeso.getText().toString());
        fAltura = Float.parseFloat(etAltura.getText().toString());

        fResultado = fPeso / (fAltura * fAltura);


        if (fResultado < 18.5){
            tvResultado.setText(String.valueOf("O seu IMC é: "+String.format("%.2f",fResultado)+" e você está abaixo do peso."));
        } else if (fResultado <= 24.9) {
            tvResultado.setText(String.valueOf("O seu IMC é: "+String.format("%.2f",fResultado)+" e você está na classificação regular."));
        } else if (fResultado <= 29.9) {
            tvResultado.setText(String.valueOf("O seu IMC é: "+String.format("%.2f",fResultado)+" e você está sobrepeso."));
        } else if (fResultado <= 39.9) {
            tvResultado.setText(String.valueOf("O seu IMC é: "+String.format("%.2f",fResultado)+" e você está na classificação 'obesidade'."));
        } else  {
            tvResultado.setText(String.valueOf("O seu IMC é: "+String.format("%.2f",fResultado)+" e você está na classificação 'obesidade severa'."));
        }
    }
    public void novo (View n){
        etPeso.setText(null);
        etAltura.setText(null);
        tvResultado.setText(null);
        etPeso.requestFocus();
    }
}