package sp.senai.br.adivinhacao;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    EditText etPalpite;
    Button btnVerificar, btnNovoSorteio;
    TextView tvResultado;
    ConstraintLayout clPrincipal;
    int iNumero;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.clPrincipal), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        etPalpite = findViewById(R.id.etPalpite);
        btnVerificar = findViewById(R.id.btnVerificar);
        btnNovoSorteio = findViewById(R.id.btnNovoSorteio);
        tvResultado = findViewById(R.id.tvResultado);
        clPrincipal = findViewById(R.id.clPrincipal);
        iNumero = (int)(Math.random()*100)+1;

    }
    public void verificar (View v){
        int Valor;

        Valor = Integer.parseInt(etPalpite.getText().toString());

        if(Valor > iNumero){
            tvResultado.setText(String.valueOf("Menor que seu palpite"));
            clPrincipal.setBackgroundColor(Color.rgb(255,0,0));
        }else if(Valor < iNumero){
            tvResultado.setText(String.valueOf("Maior que seu palpite"));
            clPrincipal.setBackgroundColor(Color.rgb(255,0,0));
        }else{
            tvResultado.setText(String.valueOf("Igual ao seu palpite"));
            clPrincipal.setBackgroundColor(Color.rgb(0,255,0));
        }
    }
    public void sorteio (View s){
        etPalpite.setText(null);
        tvResultado.setText(null);
        iNumero = (int)(Math.random()*100)+1;
        clPrincipal.setBackgroundColor(Color.parseColor("#FFFFFF"));
    }
}